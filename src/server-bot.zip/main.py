import asyncio
import logging
from datetime import timedelta
from contextlib import asynccontextmanager
import torch
import torch.nn as nn
from motor.motor_asyncio import AsyncIOMotorClient
from aiogram import Bot, Dispatcher, types, F
from aiogram.filters import Command
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton, WebAppInfo
from pyngrok import ngrok, conf
from aiogram.types import ChatMemberUpdated, ChatMemberAdministrator
from aiogram.filters.chat_member_updated import \
    ChatMemberUpdatedFilter, JOIN_TRANSITION
from transformers import AutoTokenizer, AutoModel
import torch.nn.functional as F
from aiogram.enums import ChatMemberStatus
import uvicorn
from fastapi import FastAPI, HTTPException, status
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

BOT_TOKEN = "8162619367:AAHvVY3KVyFUCkGYDQKaO6pFDDjO-e6RiwM"
MONGO_URI = "mongodb+srv://asanosmanov217_db_user:eS6IzjYCH3WdK8X4@clear-comment.ghuw75y.mongodb.net/"
DB_NAME = "clear-comment"
WEBAPP_URL = "http://your-ngrok-url.ngrok.io/webapp"
DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# --- ИНИЦИАЛИЗАЦИЯ БАЗЫ ДАННЫХ (MONGODB) ---
client = AsyncIOMotorClient(MONGO_URI)
db = client[DB_NAME]

# Коллекции
col_settings = db["chat_settings"]
col_warnings = db["warnings"]
col_whitelist = db["whitelists"]
col_base_training = db["base_model_training_data"]
col_logs = db["toxic_logs"]

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# --- МОДЕЛИ МАШИННОГО ОБУЧЕНИЯ ---

class ToxicBERTv4(nn.Module):
    def __init__(self, hidden_dim=512, dropout_prob=0.3):
        super(ToxicBERTv4, self).__init__()

        h_size = 1024

        #--- Блок 1 ---
        self.attn1 = nn.MultiheadAttention(embed_dim=h_size, num_heads=16, batch_first=True)
        self.norm1_1 = nn.LayerNorm(h_size)
        self.ffn1 = nn.Sequential(
            nn.Linear(h_size, h_size*2),
            nn.ReLU(),
            nn.Dropout(dropout_prob/2),
            nn.Linear(h_size*2, h_size),
            nn.ReLU(),
            nn.Dropout(dropout_prob/2)
        )
        self.norm1_2 = nn.LayerNorm(h_size)

        # --- Блок 2 ---
        self.attn2 = nn.MultiheadAttention(embed_dim=h_size, num_heads=16, batch_first=True)
        self.norm2_1 = nn.LayerNorm(h_size)
        self.ffn2 = nn.Sequential(
            nn.Linear(h_size, h_size*2),
            nn.ReLU(),
            nn.Dropout(dropout_prob/2),
            nn.Linear(h_size*2, h_size),
            nn.ReLU(),
            nn.Dropout(dropout_prob/2)
        )
        self.norm2_2 = nn.LayerNorm(h_size)

        # --- Блок 3 ---
        self.attn3 = nn.MultiheadAttention(embed_dim=h_size, num_heads=16, batch_first=True)
        self.norm3_1 = nn.LayerNorm(h_size)
        self.ffn3 = nn.Sequential(
            nn.Linear(h_size, h_size*2),
            nn.ReLU(),
            nn.Dropout(dropout_prob/2),
            nn.Linear(h_size*2, h_size),
            nn.ReLU(),
            nn.Dropout(dropout_prob/2)
        )
        self.norm3_2 = nn.LayerNorm(h_size)

        self.lstm = nn.LSTM(
            input_size=1024,
            hidden_size=hidden_dim,
            num_layers=1,
            batch_first=True,
            bidirectional=True,
            dropout=0.07
        )

        #LSTM двунаправленная потому умножаем на 2
        self.head = nn.Sequential(
            nn.Linear(hidden_dim*2, hidden_dim),
            nn.ReLU(),
            nn.Dropout(dropout_prob/1.5),
            nn.Linear(hidden_dim, hidden_dim//2),
            nn.ReLU(),
            nn.Dropout(dropout_prob),
            nn.Linear(hidden_dim//2, 2),
        )

    def forward(self, input):

        # Берем последние 4 слоя из hidden_states (кортеж из 13 слоев: 0 - embedding, 1-12 - layers)
        #hidden_states = input_ids.hidden_states[-4:]
        x = input.last_hidden_state # [Batch, Seq, Hidden]

        # 2. Блок внимания 1 (Add & Norm)
        attn_out, _ = self.attn1(x, x, x)
        x = self.norm1_1(x + attn_out) # Residual + Norm
        ffn_out = self.ffn1(x)
        x = self.norm1_2(x + ffn_out)  # Residual + Norm

        # 3. Блок внимания 2 (Add & Norm)
        attn_out, _ = self.attn2(x, x, x)
        x = self.norm2_1(x + attn_out)
        ffn_out = self.ffn2(x)
        x = self.norm2_2(x + ffn_out)

        # 4. Блок внимания 3 (Add & Norm)
        attn_out, _ = self.attn3(x, x, x)
        x = self.norm3_1(x + attn_out)
        ffn_out = self.ffn3(x)
        x = self.norm3_2(x + ffn_out)

        lstm_out, (h_n, c_n) = self.lstm(x)

        last_h = torch.cat((h_n[-2,:,:], h_n[-1,:,:]), dim=1)

        logits = self.head(last_h)

        return logits

modelv4 = ToxicBERTv4().to(device)
modelv4.load_state_dict(torch.load('toxic-bert-v6-1-epoch-3.pth',map_location=torch.device('cpu'))['model_state_dict'])
modelv4.eval()

class RuBertEncoder:
    def __init__(self, model_name='ai-forever/ruRoberta-large', device='cuda'):
        self.device = device
        self.tokenizer = AutoTokenizer.from_pretrained(model_name)
        self.bert = AutoModel.from_pretrained(model_name, output_hidden_states=True).to(device)
        self.bert.eval() # Всегда в режиме оценки

    @torch.no_grad()
    def encode_batch(self, texts):
        """Преобразует батч текстов в батч эмбеддингов [Batch, Seq, 768]"""
        inputs = self.tokenizer(texts,
            add_special_tokens=True,
            max_length=128,
            padding='max_length',
            truncation=True,
            return_tensors='pt').to(self.device)
        outputs = self.bert(**inputs)

        return outputs

encoder = RuBertEncoder(device=device)

custom_heads = {}
training_buffers = {}

async def predict_toxicity(text, chat_id):
    with torch.no_grad():
        input = encoder.encode_batch(text)
        outputs = modelv4(input)
    return F.softmax(outputs)[0][0]

# --- TELEGRAM BOT ---
bot = Bot(token=BOT_TOKEN)
dp = Dispatcher(drop_pending_updates=True)

@dp.message(Command("add"))
async def cmd_add(message: types.Message):
    """Очистка буфера перед приемом новых сообщений согласно протоколу."""
    training_buffers[message.from_user.id] = []
    await message.answer("Буфер данных очищен. Ожидание 64+ комментариев для обучения.")

@dp.message(Command("train"))
async def cmd_train(message: types.Message):
    buffer = training_buffers.get(message.from_user.id, [])
    if len(buffer) < 64:
        await message.answer(f"Недостаточно данных: {len(buffer)}/64.")
        return
    # Логика дообучения...
    training_buffers[message.from_user.id] = []
    await message.answer("Дообучение завершено успешно.")

@dp.message(Command("ban"))
async def cmd_manual_ban(message: types.Message):
    if not message.reply_to_message: return
    if message.chat.type not in ["group", "supergroup"]:
        return
    member = await message.bot.get_chat_member(chat_id=message.chat.id, user_id=message.from_user.id)
    # Проверяем, является ли он админом или создателем
    if member.status not in [ChatMemberStatus.ADMINISTRATOR, ChatMemberStatus.CREATOR]:
        await message.answer("У вас нет прав для выполнения этой команды.")
        return

    if not message.reply_to_message: return
    try:
        await bot.ban_chat_member(message.chat.id, message.reply_to_message.from_user.id)
        await col_base_training.insert_one({
            "text": message.reply_to_message.text,
            "label": 0,
            "source": "manual_ban"
        })
        await message.reply_to_message.delete()
        await message.answer("Пользователь заблокирован.")
    except Exception as e:
        await message.answer(f"Ошибка доступа: {str(e)}")

@dp.message(Command("del"))
async def cmd_manual_del(message: types.Message):
    if not message.reply_to_message: return

    if message.chat.type not in ["group", "supergroup"]:
        return

    member = await message.bot.get_chat_member(chat_id=message.chat.id, user_id=message.from_user.id)

    # Проверяем, является ли он админом или создателем
    if member.status not in [ChatMemberStatus.ADMINISTRATOR, ChatMemberStatus.CREATOR]:
        await message.answer("У вас нет прав для выполнения этой команды.")
        return
    try:
        print(message.reply_to_message.text)
        await col_base_training.insert_one({
            "text": message.reply_to_message.text,
            "label": 0,
            "source": "manual_delete"
        })
        await message.reply_to_message.delete()
        await message.answer("Сообщение удалено.")
    except Exception as e:
        await message.answer(f"Ошибка доступа: {str(e)}")

@dp.message()
async def process_messages(message: types.Message):

    if message.chat.type == "private":
        buf = training_buffers.setdefault(message.from_user.id, [])
        buf.append(message.text)
        await message.answer(f"Собрано: {len(buf)}/64")
        return
    chat_id, user_id = message.chat.id, message.from_user.id

    # Проверка белого списка
    if await col_whitelist.find_one({"chatId": chat_id, "userId": user_id}):
        return

    # Получение настроек чата
    settings = await col_settings.find_one({"chatId": chat_id})
    threshold = settings.get("threshold", 0.1) if settings else 0.1
    action = settings.get("action_type", "delete") if settings else "delete"

    text = message.text or message.caption
    if not text: return

    score = await predict_toxicity(text, chat_id)
    print(score,chat_id)
    if score >= threshold:
        await col_logs.insert_one({"chatId": chat_id, "text": text,  "userId": user_id, "is_reviewed": False})

        try:
            await message.delete()
            if action == "warn":
                res = await col_warnings.find_one_and_update(
                    {"chatId": chat_id, "userId": user_id},
                    {"$inc": {"count": 1}},
                    upsert=True, return_document=True
                )
                max_w = settings.get("max_warnings", 3) if settings else 3
                if res["count"] >= max_w:
                    await bot.ban_chat_member(chat_id, user_id)
                    await message.answer("Лимит предупреждений исчерпан. Бан.")
                else:
                    await message.answer(f"Предупреждение: {res['count']}/{max_w}")
            elif action == "ban":
                dur = settings.get("ban_duration", 0) if settings else 0
                until = message.date + timedelta(minutes=dur) if dur > 0 else None
                await bot.ban_chat_member(chat_id, user_id, until_date=until)
        except Exception:
            pass

@dp.my_chat_member(ChatMemberUpdatedFilter(member_status_changed=JOIN_TRANSITION))
async def on_bot_added(event: ChatMemberUpdated):
    new_state = event.new_chat_member

    if isinstance(new_state, ChatMemberAdministrator):
        required_permissions = {
            "can_delete_messages": "Удаление сообщений",
            "can_restrict_members": "Блокировка пользователей",
        }
        missing = []
        for attr, name in required_permissions.items():
            if not getattr(new_state, attr, False):
                missing.append(name)

        if missing:
            missing_str = ", ".join(missing)
            await event.answer(
                f"⚠️ Спасибо за права администратора, но мне не хватает:\n"
                f"**{missing_str}**\n"
                "Чтобы я мог модерировать чат, удалите меня из группы и заново добавьте с правами администратора."
            )
        else:
            await event.answer("✅ Принят! Все необходимые права выданы.")
            chat = await bot.get_chat(chat_id=event.chat.id);
            await col_settings.insert_one({"chatId": event.chat.id, "userId": event.from_user.id,"action_type":"delete","threshold":0.0,"title":(chat.title or "-"), "description":(chat.description or "-"),"model":"base-15m"})
    else:
        # 2. Если бот добавлен как обычный участник
        await event.answer(
            "👋 Привет! Я добавлен как обычный участник.\n"
            "Чтобы я мог модерировать чат, удалите меня из группы и заново добавьте с правами администратора."
        )

# Твой токен от ngrok (можно получить в личном кабинете ngrok.com)
NGROK_AUTH_TOKEN = "3CrXCFix7HlNUHckN4ybnviTNpW_oWsbXzPQpNcfd2L4mmPU"
PORT = 3000

app = FastAPI(title="Telegram Bot API")

@app.on_event("startup")
async def main():
    logging.basicConfig(level=logging.INFO)
    asyncio.create_task(dp.start_polling(bot, allowed_updates=["message", "chat_member", "my_chat_member"]))

origins = [
    "http://192.168.1.46:3000", "http://localhost:3000", "http://10.99.5.97:3000", "https://stegosaur-clumsily-zodiac.ngrok-free.dev"
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,            # Разрешенные сайты
    allow_credentials=True,
    allow_methods=["*"],              # Разрешить все методы (GET, POST, OPTIONS и т.д.)
    allow_headers=["*"],              # Разрешить любые заголовки (Headers)
)
class MessageSchema(BaseModel):
    chatId: int
    userId: int

@app.post("/unban-user")
async def send_message_to_tg(payload:MessageSchema):
    try:
        await bot.unban_chat_member(chat_id=payload.chatId, user_id=payload.userId, only_if_banned=True)
        await col_logs.delete_one({"chatId": payload.chatId, "userId":payload.userId})
        return {"success": True}
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Ошибка бота: {str(e)}"
        )


# --- ИЗМЕНЕННЫЙ БЛОК ЗАПУСКА ---
if __name__ == "__main__":
    # 1. Настройка ngrok
    conf.get_default().auth_token = NGROK_AUTH_TOKEN

    # 2. Открываем туннель
    # Мы указываем bind_tls=True, так как Telegram требует HTTPS для Mini Apps
    public_url = ngrok.connect(PORT, bind_tls=True).public_url
    print(f"\n[NGROK] Туннель создан: {public_url}")
    print(f"[INFO] Ссылка для Telegram Mini App: {public_url}")
    print(f"[HINT] Не забудь обновить URL в настройках BotFather!\n")
    try:
        uvicorn.run("main:app", host="127.0.0.1", port=8000, reload=False)
    except KeyboardInterrupt:
        print("\n[INFO] Выключение сервера...")
    finally:
        # Закрываем туннель при выходе
        ngrok.disconnect(public_url)











