import cors from "cors"
import express from "express";
import mongoose, {Schema} from "mongoose";
const app = express()

const PORT = 5000;
const MONGO = "mongodb+srv://asanosmanov217_db_user:eS6IzjYCH3WdK8X4@clear-comment.ghuw75y.mongodb.net/clear-comment";
app.use(express.json());
app.use(cors({
    origin: [
        "http://192.168.1.46:3000", "http://localhost:3000", "http://10.99.5.97:3000", "https://stegosaur-clumsily-zodiac.ngrok-free.dev"
    ],
    credentials: true,
}));


const chatSettings = mongoose.model('chat_settings', new Schema({
    chatId: {
        type: Number,
        required: true
    },
    userId: {
        type: Number,
        required: true
    },
    action_type: {
        type: String,
        enum: ["delete", "ban"],
        required: true,
    },
    threshold: {
        type: Number,
        required: true
    },
    title: {
        type: String,
        required: true,
    },
    description: {
        type: String,
        required: true,
    },
    model: {
        type: String,
        enum: ["robert-large-hydra-27m"],
        required: true,
    },
}));
const whitelist = mongoose.model('whitelists', new Schema({
    chatId: {
        type: Number,
        required: true
    },
    userId: {
        type: Number,
        required: true
    },
}));
const toxicLogs = mongoose.model('toxic_logs', new Schema({
    chatId: {
        type: Number,
        required: true
    },
    text: {
        type: String,
        required: true
    },
}));


app.post('/get-chat-list', async (req, res) => {
    try{
        const {userId} = req.body;

        const response = await chatSettings.find({userId});
        //console.log(response);
        if(!response) {
            res.status(404);
            return;
        }
        res.json(response);
    }catch (e) {
        console.log(e)
        res.status(500);
    }
});

app.post('/get-chat-settings', async (req, res) => {
    try{
        const {userId, chatId} = req.body;

        const response = await chatSettings.findOne({userId,chatId}).lean();
        let white_list = await whitelist.find({chatId:chatId}).lean();

        //console.log(response);
        if(!response){
            res.status(404);
            return;
        }
        response.whitelist = white_list;
        response.threshold = Math.sqrt(response.threshold);
        res.json(response);
    }catch (e) {
        console.log(e)
        res.status(500);
    }
});

app.post('/update-chat-settings', async (req, res) => {
    try{
        const data = req.body;
        data.threshold = data.threshold**2;
        let add_user_to_whitelist = [];
        let prev_whitelist = await whitelist.find({chatId:data.chatId}).lean();

        for (const whitelistKey of data.whitelist) {
            let index = prev_whitelist.findIndex(element => element.userId === whitelistKey)
            if(index !== -1) {
                prev_whitelist.splice(index,1);
            }else{
                add_user_to_whitelist.push({userId:whitelistKey,chatId:data.chatId});
            }
        }

        await whitelist.deleteMany({userId: { $in: prev_whitelist.map(key=>{return key.userId}) }});
        let r = await whitelist.insertMany(add_user_to_whitelist);


        delete data.description;
        delete data.title;
        delete data.whitelist;
        const response = await chatSettings.findOneAndUpdate({userId:data.userId,chatId:data.chatId}, {"$set":data} );

        if(!response){
            res.status(404).json("bad");
            return;
        }

        res.json(response);
    }catch (e) {
        console.log(e)
        res.status(500);
    }
});

app.post('/get-chat-toxic-logs', async(req, res) => {
    try{
        const {chatId} = req.body;
        let list = await toxicLogs.find({chatId:chatId}).lean();

        //console.log(response);
        if(!list){
            res.status(404);
            return;
        }

        res.json(list);
    }catch (e) {
        console.log(e)
        res.status(500);
    }
});


async function start(){
    try{
        // Start the server
        app.listen(PORT, () => {
            console.log(`Приложение работает на порту ${PORT}`);
        });
        await mongoose.connect(MONGO);
    }catch (e) {
        console.log(e)
    }
}
start()