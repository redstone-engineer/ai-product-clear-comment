"use client"

import React, {useState} from 'react';
import {Field, FieldDescription, FieldLabel} from "@/components/ui/field";
import {Input} from "@/components/ui/input";
import {Select,SelectContent, SelectGroup, SelectItem, SelectLabel, SelectTrigger, SelectValue} from "@/components/ui/select";
import {Button} from "@/components/ui/button";
import {MoveLeft} from "lucide-react"
import Link from 'next/link'
import axios from "axios";

export default function Page() {
    const [name, setName] = useState("")
    const [nameOk, setNameOk] = useState(true)
    async function submit(e) {
        try {
            if(!(/^(\w)+$/.test(name))){
                setNameOk(false);
                return;
            }
            setNameOk(true);
            let response = await axios.post("http://localhost:5000/" + "")
        }catch (e) {
        }
    }

    return (
        <div className={"grid gap-4"}>
            <Link href="/">
                <MoveLeft size={36} />
            </Link>
            <h2 className={"text-[#ffffff] text-3xl"}  >Добавление нового чата</h2>
            <p className={"text-[#999999] text-sm"} >Для начала убдедитесь, что вы обладаете правами администратора и бот сможет удалять сообщения</p>
            <Field>
                <FieldLabel className={"text-xl"} htmlFor="first-name">@Название чата</FieldLabel>
                <p className={"text-destructive text-sm font-[Nunito]"}>{!nameOk ? "некорректное название" : ""}</p>
                <Input onChange={(e)=>{setName(e.target.value);console.log(e.target.value)}}
                       id="chat-name"
                    placeholder="chat_name" className={"max-w-[500px]"}
                />
            </Field>
            <Field>
                <FieldLabel className={"text-xl"}  htmlFor="first-name">ИИ модель</FieldLabel>
                <Select onClick={()=>{console.log("dddddddddd")}}  className={"z-[999]"} modal={false}>
                    <SelectTrigger className="w-full max-w-48">
                        <SelectValue placeholder="Выберите модель" />
                    </SelectTrigger>
                    <SelectContent>
                        <SelectGroup>
                            <SelectItem className={"text-[#aaaaaa]"} value="base-15m">base-15m</SelectItem>
                        </SelectGroup>
                    </SelectContent>
                </Select>
            </Field>
            <Button onClick={submit} size={"default"} variant="default" className={"w-[100%]"}>
                <p>Добавить бота в чат</p>
            </Button>
        </div>
    );
};
