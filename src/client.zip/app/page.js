"use client"

import { Button } from "@/components/ui/button"
import {
    Card,
    CardAction,
    CardContent,
    CardDescription,
    CardFooter,
    CardHeader,
    CardTitle,
} from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import Link from 'next/link'
import React, {useEffect, useState} from "react";
import {ScrollArea} from "@/components/ui/scroll-area";
import {Item, ItemActions, ItemContent, ItemDescription, ItemTitle} from "@/components/ui/item";
import axios from "axios";

export default function Home() {

    const [chatData ,setChatData] = useState([]);

    async function getData() {
        try {
            let response = await axios.post("http://localhost:5000/get-chat-list",{userId:2101317052});
            setChatData(response.data)
        }catch (e) {
            console.log(e);
        }
    }

    useEffect(() => {
        getData();
    }, []);


    return (
        <div className={"grid grid-rows-[auto_auto_auto_1fr] grid-rows-6 h-[100%] gap-3"}>
            <div>
                <h1 className={"text-foreground text-3xl"}>Clear Comment</h1>
            </div>
            <div>
                <p className={"text-primary text-sm"}>Просто добавьте бот в ваш чат и обновите страницу. Вы увидите новый чат в списке. Но для начала убедитесь, что вы обладаете правами администратора и бот сможет удалять сообщения, иначе чат в списке не отобразится.</p>
            </div>
            <div>
                <h3 className={"text-foreground text-xl"}>Модерируемые чаты</h3>
            </div>
            <ScrollArea className=" w-[100%] rounded-md border rounded-xl ">
                {
                    chatData.map((key) => {
                        return <Link key={key.chatId} href={"/settings/chat/" + key.chatId}>
                            <Item className={"m-[10px] w-[calc(100%_-_20px)] hover:cursor-pointer"} variant="outline">
                                <ItemContent>
                                    <ItemTitle>{key.title}</ItemTitle>
                                    <ItemDescription>

                                    </ItemDescription>
                                </ItemContent>
                                <ItemActions>
                                    <Button variant="outline" size="sm">
                                        Детали
                                    </Button>
                                </ItemActions>
                            </Item>
                        </Link>
                    })
                }
            </ScrollArea>
        </div>
    )
}