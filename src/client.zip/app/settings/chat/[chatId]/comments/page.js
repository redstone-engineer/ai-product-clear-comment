"use client"

import React, {useEffect, useState} from 'react';
import {useParams} from "next/navigation";
import Link from "next/link";
import {MoveLeft, X , Gavel} from "lucide-react";
import {Item, ItemActions, ItemContent, ItemDescription, ItemMedia, ItemTitle} from "@/components/ui/item";
import {Avatar, AvatarFallback} from "@/components/ui/avatar";
import {Button} from "@/components/ui/button";
import {ScrollArea} from "@/components/ui/scroll-area";
import axios from "axios";
import {ButtonGroup} from "@/components/ui/button-group";
import { Kbd, KbdGroup } from "@/components/ui/kbd"
import {
    Tooltip,
    TooltipContent, TooltipProvider,
    TooltipTrigger,
} from "@/components/ui/tooltip"

const Page = () => {
    const { chatId } = useParams();
    const [chatData,setChatData] = useState([]);
    async function getData() {

        try {
            let response = await axios.post("http://localhost:5000/get-chat-toxic-logs",{chatId:parseInt(chatId)});
            if(response.data) {
                console.log("Error");
            }
            setChatData(response.data)

        }catch (e) {
            console.log(e);
        }
    }

    async function unban_user(userId,num){
        try {
            let response = await axios.post("http://localhost:8000/unban-user",{chatId:parseInt(chatId),userId:userId});
            if(response.data) {
                console.log("Error");
            }
            let newChatData = [...chatData];
            newChatData.splice(num,1);
            setChatData(newChatData);
        }catch (e) {
            console.log(e);
        }
    }

    useEffect(() => {
        getData();
    }, []);

    return (
        <div className={"grid gap-4"}>
            <Link href={"/settings/chat/" + chatId}>
                <MoveLeft size={36}/>
            </Link>
            <h2 className={"text-[#ffffff] text-2xl"}>Список Комментариев</h2>
            <ScrollArea className="p-2 w-[100%] max-h-[90vh] overflow-hidden scroll-smooth rounded-md border">
                <div className="w-[100%] grid grid-cols-[1fr] gap-2">
                    {
                        chatData.map((value,index)=>{
                            return <Item key={value._id} variant="outline">
                                <ItemContent>
                                    <ItemDescription>{value.text}</ItemDescription>
                                </ItemContent>
                                <ItemActions>
                                    <ButtonGroup>
                                        <TooltipProvider>
                                            <Tooltip>
                                                <TooltipTrigger onClick={()=>{unban_user(value.userId,index)}} asChild>
                                                    <Button className={"cursor-pointer"} variant="secodary"><Gavel/></Button>
                                                </TooltipTrigger>
                                                <TooltipContent>
                                                    <p className={"font-[NunitoSemiBold]"}>Разбанить пользователя</p>
                                                </TooltipContent>
                                            </Tooltip>
                                        </TooltipProvider>
                                    </ButtonGroup>
                                </ItemActions>
                            </Item>
                        })
                    }
                </div>
            </ScrollArea>
        </div>
    );
};

export default Page;