"use client"

import React, {useEffect, useState} from 'react';
import Link from "next/link";
import {MoveLeft} from "lucide-react";
import {Field, FieldDescription, FieldLabel} from "@/components/ui/field";
import {Input} from "@/components/ui/input";
import {Select, SelectContent, SelectGroup, SelectItem, SelectTrigger, SelectValue} from "@/components/ui/select";
import {Button} from "@/components/ui/button";
import axios from "axios";
import {useParams} from "next/navigation";
import {ScrollArea} from "@/components/ui/scroll-area";
import {Item, ItemActions, ItemContent, ItemDescription, ItemMedia, ItemTitle} from "@/components/ui/item";
import {
    Avatar,
    AvatarFallback,
    AvatarImage,
} from "@/components/ui/avatar"
import { X } from "lucide-react"
import {Separator} from "@/components/ui/separator";



export default function Page () {
    const { chatId } = useParams();
    const [thresholdOk, setThresholdOk ] = useState(true);
    const [chatData,setChatData] = useState({
        chatId:0,
        userId:0,
        title:"",
        model:"",
        action_type:"",
        threshold:0,
    });
    const [whitelistUser,setWhitelistUser] = useState("");
    const [whitelist,setWhitelist] = useState(new Set());

    async function getData() {

        try {
            let response = await axios.post("http://localhost:5000/get-chat-settings",{chatId:parseInt(chatId),userId:2101317052});
            if(response.data) {
                console.log("Error");
            }
            let get_whitelist = [];
            for (const whitelistElement of response.data.whitelist) {
                get_whitelist.push(whitelistElement.userId);
            }
            setWhitelist(new Set(get_whitelist));
            delete response.data.whitelist;
            setChatData(response.data)

        }catch (e) {
            console.log(e);
        }
    }

    useEffect(() => {
        getData();
    }, []);

    async function submit(e) {
        try {
            chatData.whitelist = Array.from(whitelist);
            let response = await axios.post("http://localhost:5000/update-chat-settings",chatData);
            if(response.data.ok){
                console.log("Ok")
            }
            //setChatData(response.data)
        }catch (e) {
            console.log(e);
        }
    }

    function add_user_in_whitelist(e) {
        try {
            if(whitelistUser === "" || isNaN(parseInt(whitelistUser))){
                return;
            }
            setWhitelist(new Set([...whitelist,parseInt(whitelistUser)]));
        }catch (e) {
            console.log(e);
        }
    }

    function delete_user_from_whitelist(user) {
        try {
            let set = new Set([...whitelist]);
            set.delete(user);
            setWhitelist(set);
        }catch (e) {
            console.log(e);
        }
    }
    return (
        <div className={"grid gap-4"}>
            <Link href="/">
                <MoveLeft size={36}/>
            </Link>
            <h2 className={"text-[#ffffff] text-2xl"}>Настройки</h2>
            <Link href={"/settings/chat/" + chatId + "/comments"}>
                <Button size={"default"} variant="outline" className={"max-w-[300px]"}>
                    <p>Список заблокированных комментариев</p>
                </Button>
            </Link>
            <Field>
                <FieldLabel className={"text-lg"} htmlFor="first-name">@Название чата</FieldLabel>
                <Input
                       id="chat-name"
                        className={"max-w-[500px] text-[#ffffff]"}
                       defaultValue={chatData.title || ""}
                       readOnly
                />
            </Field>
            <Separator/>
            <Field>
                <FieldLabel className={"text-base"} htmlFor="first-name">ИИ модель</FieldLabel>
                <Select onValueChange={(value) => {
                    setChatData({...chatData,model:value});
                }} value={chatData.model}  modal={false}>
                    <SelectTrigger className="w-full max-w-48">
                        <SelectValue placeholder="Выберите модель"/>
                    </SelectTrigger>
                    <SelectContent>
                        <SelectGroup>
                            <SelectItem className={"text-[#aaaaaa] font-[NunitoSemiBold]"} value="robert-large-27m">robert-large-hydra-27m</SelectItem>
                            <SelectItem className={"text-[#aaaaaa] font-[NunitoSemiBold]"} value="robert-large-21m">robert-large-modern-21m</SelectItem>
                            <SelectItem className={"text-[#aaaaaa] font-[NunitoSemiBold]"} value="robert-large-19m">robert-large-rust-19m</SelectItem>
                        </SelectGroup>
                    </SelectContent>
                </Select>
            </Field>
            <Separator/>
            <Field>
                <FieldLabel className={"text-base"} htmlFor="first-name">Реакция бота на деструктивные сообщения</FieldLabel>
                <Select onValueChange={(value) => {
                    console.log(value)
                    setChatData({...chatData,action_type:value});
                }} value={chatData.action_type} modal={false}>
                    <SelectTrigger className="w-full max-w-64">
                        <SelectValue placeholder="Выберите ответ"/>
                    </SelectTrigger>
                    <SelectContent>
                        <SelectGroup>
                            <SelectItem className={"text-[#aaaaaa] font-[NunitoSemiBold]"} value="delete">Удалить комментарий</SelectItem>
                            <SelectItem className={"text-[#aaaaaa] font-[NunitoSemiBold]"} value="ban">Забанить пользователя</SelectItem>
                        </SelectGroup>
                    </SelectContent>
                </Select>
            </Field>
            <Separator/>
            <Field>
                <FieldLabel className={"text-base"} htmlFor="first-name">Порог для бана</FieldLabel>
                <Input onChange={(e)=>{
                    const c= parseFloat(e.target.value);
                    setThresholdOk(!(isNaN(c) || c > 1 || c < 0));
                    setChatData({...chatData,threshold:(isNaN(c) || c > 1 || c < 0) ? 1 : c});
                }}
                    aria-invalid={!thresholdOk}
                    id="chat-name"
                    className={"max-w-[100px] text-[#ffffff]"}
                    placeholder={"0.38"}
                    defaultValue={chatData.threshold}
                />
                <FieldDescription className={"text-xs"}><span  style={{ whiteSpace: 'pre-line' }}>{"0 - бан абсолютно всех подряд.\n1 - полное отсутствие модерации.\nДля family-friendly чата желательно установить 0.25-0.35\nДля более свободных чатов можно установить 0.5-0.6\nНо лучше параметр подбирать самостоятельно."}</span></FieldDescription>
            </Field>
            <Separator/>
            <Field>
                <FieldLabel className={"text-base"} htmlFor="first-name">Белый список</FieldLabel>
                <FieldDescription className={"text-xs"}><span  style={{ whiteSpace: 'pre-line' }}>{"Список людей, которых ии не будет банить в автоматическом режиме. Введите userId пользозователя."}</span></FieldDescription>
                <Input onChange={(e)=>{
                    setWhitelistUser(e.target.value);
                }}
                       id="white-list-user-name"
                       className={"max-w-[200px] text-[#ffffff]"}
                />
                <Button onClick={add_user_in_whitelist} size={"default"} variant="outline" className={"max-w-[300px]"}>
                    <p>Добавить пользователя</p>
                </Button>
                <ScrollArea className="p-2 w-[100%] max-h-[50vh] overflow-hidden scroll-smooth rounded-md border">
                    <div className="w-[100%] grid grid-cols-[1fr] gap-2">
                    {
                        Array.from(whitelist).map((value)=>{
                            return <Item key={value} variant="outline">
                                <ItemMedia>
                                    <Avatar className="size-10">
                                        <AvatarFallback></AvatarFallback>
                                    </Avatar>
                                </ItemMedia>
                                <ItemContent>
                                    <ItemTitle>{value}</ItemTitle>
                                </ItemContent>
                                <ItemActions>
                                    <Button
                                        onClick={() => {delete_user_from_whitelist(value)}}
                                        size="icon-sm"
                                        variant="outline"
                                        className="rounded-full"
                                        aria-label="Invite"
                                    >
                                        <X/>
                                    </Button>
                                </ItemActions>
                            </Item>
                        })
                    }
                    </div>
                </ScrollArea>
            </Field>
            <Button onClick={submit} size={"default"} variant="default" className={"w-[100%]"}>
                <p>Изменить настройки</p>
            </Button>
            <div className={"p-3"}>

            </div>
        </div>
    );
};

