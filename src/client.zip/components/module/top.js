import React from 'react';
import {Button} from "@/components/ui/button";

const Top = () => {
    return (
        <div className={"w-full bg-[#00000055] h-20 backdrop-blur-sm flex flex-wrap items-center justify-center"}>
            <div className={"w-[90%] flex"}>
                <Button className={"bg-color-sidebar-border"} variant="outline">Список</Button>
                <Button className={"bg-color-sidebar-border"} variant="outline"></Button>
            </div>
        </div>
    );
};

export default Top;